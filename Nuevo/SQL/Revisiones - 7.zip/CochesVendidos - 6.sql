INSERT INTO CochesVendidos (Matricula, Marca, Modelo, Color, Precio, ExtrasInstalados, CodigoCliente) VALUES
('V2360OX', 'Opel', 'Corsa 1.2 Sport', 'Azul', 2100000.00, 'Antena eléctrica', 100),
('V1010PB', 'Ford', 'Probe 2.0 16V', 'Blanco', 2860000.00, NULL, 101),
('V4578OB', 'Ford', 'Orion 1.8 Ghia', 'Negro', 2600000.00, 'Aire Acondicionado', 105),
('V7648OU', 'Citroen', 'Xantia 16V', 'Negro', 2480000.00, 'Airbag', 225),
('V3543NC', 'Ford', 'Escort 1.6 Ghia', 'Rojo', 2500000.00, NULL, 260),
('V7632NX', 'Citroen', 'Zx Turbo-D', 'Rojo', 2800000.00, 'Aire Acondicionado, Airbag', 289),
('V8018LJ', 'Ford', 'Fiesta 1.4 CLX', 'Azul', 1950000.00, 'Elevalunas eléctricos', 352),
('V2565NB', 'Renault', 'Clio 1.7 S', 'Blanco', 2100000.00, NULL, 390),
('V7642OU', 'Ford', 'Mondeo 1.8 GLX', 'Blanco', 3100000.00, NULL, 810),
('V1234LC', 'Audi', '100 2.3', 'Verde', 3510000.00, 'Climatizador', 822),
('V9834LH', 'Peugeot', '205 GTI', 'Rojo', 2450000.00, NULL, 860);